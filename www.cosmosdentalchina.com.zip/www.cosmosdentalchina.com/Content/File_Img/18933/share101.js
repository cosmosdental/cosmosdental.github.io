﻿document.writeln("<li><a href=\"javascript:window.print();\"><img src=\"/images/Common/Print.jpg\">Print this Page</a></li>");
document.writeln("<li><a href=\"javascript:void(0);\" onclick=\"addFavorite();\"><img src=\"/images/Common/Bookmark.jpg\">Bookmark this</a></li>");
document.writeln("<li><a href=\"#F1\" id=\"mysub\"><img src=\"/images/Common/InquiryProduct.jpg\">Inquiry product</a></li>");
document.writeln("<li><a id=\"A_9\" href=\"mailto:sales@cosmos-dent.com\"><img src=\"/images/Common/Email222.jpg\">E-mail Us</a></li>");