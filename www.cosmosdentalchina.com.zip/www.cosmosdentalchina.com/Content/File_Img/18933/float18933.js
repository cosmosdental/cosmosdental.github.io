﻿var FeedbackUtil = {
    feed: function (feedbackurl) {
        var stylehtml = '<style>';
        stylehtml += '#feedback{background:#9fa0a4;width:310px;z-index:10000;position: fixed;top: 244px;z-index:99999999;}';
        stylehtml += '#feedback .section{border:1px solid #808f81;border-bottom:none;padding:10px 25px 25px;}';
        stylehtml += '#feedback h6{background:url(/images/Common3/feedback.png) no-repeat;height:38px;margin:5px 0 12px;text-indent:-99999px;cursor:pointer;}.email{word-break: break-all;}';
        stylehtml += '#feedback input{background-color:#fff;border:1px solid #dedede;color:#666666;font:13px Arial, sans-serif;height:25px;line-height:25px;padding:10px;width:234px;resize:none;outline:none;overflow:auto;margin-bottom:10px;}';
        stylehtml += '#feedback textarea{background-color:#fff;border:none;color:#666666;font:13px Arial, sans-serif;height:100px;padding:10px;width:236px;resize:none;outline:none;overflow:auto;-moz-box-shadow:4px 4px 0 #8a9b8c;-webkit-box-shadow:4px 4px 0 #8a9b8c;box-shadow:4px 4px 0 #8a9b8c;}';
        stylehtml += '#feedback a.submit{background:url(/images/Common3/submit.png) no-repeat;border:none;display:block;height:34px;margin:20px auto 0;text-decoration:none;text-indent:-99999px;width:91px;cursor:pointer;}';
        stylehtml += '#feedback a.submit:hover{background-position:left bottom;}';
        stylehtml += '#feedback a.submit.working{background-position:top right !important;cursor:default;}';
        stylehtml += '#feedback .message{font-family:Arial, sans-serif;color:#666;text-shadow:1px 1px 0 #c7c7c7;margin-bottom:20px;}';
        stylehtml += '#feedback .arrow{background:url(/images/Common3/arrows.png) no-repeat;float:right;width:24px;height:24px;position:relative;top:10px;}';
        stylehtml += '</style>';
        var bghtml = '';
        var html = stylehtml + bghtml;
        html += '<div id="feedback">';
        html += '<div class="section">';
        html += '<h6><span class="arrow" onclick="FeedbackUtil.close();return false;"></span></h6>';
        html += '<p class="message">Please include your contact information if you\'d like to receive a reply.<br></p>';
        html += '<p><input type="text" name="SubmitEmail_Float" id="SubmitEmail_Float" placeholder="E-mail"};"></p>';
        html += '<textarea name="SubmitContent_Float" id="SubmitContent_Float"></textarea>';
        html += '<a class="submit" onclick="submitFloatInquiry()" id="ImgSend_Float">Submit</a> </div>';
        html += '</div>';
        $('body').append(html);
    },
    close: function () {
        $('#feedback').remove();
    }
};

document.writeln("<style type=\'text/css\'>");
document.writeln(".box_os{ height:auto; overflow:hidden; width:169px; position:fixed; right:0; top:244px; _position:absolute; z-index:99999999;font-size:13px;display:none;}");
document.writeln(".box_os .os_x{ background:url(/images/Common3/bkefu_01.png) no-repeat; width:169px; height:44px; float:right; display:inline; cursor:pointer;}");
document.writeln(".box_os .osqq{ width:169px; background:#e5070f; clear:both;}");
document.writeln(".box_os .osqq ul{ padding:5px 0 5px 16px; border-top:1px solid #ed5257}.box_os .osqq ul a{color:#fff; text-decoration:none}");
document.writeln(".box_os .osqq ul li{ height:30px; line-height:30px;color:#fff; }");
document.writeln(".box_os .osqq .finqury{margin:0; padding:6px 0 0 0;border-top:1px solid #ed5257;}");
document.writeln(".box_os .osqq .fshare{border-top:1px solid #bcbdbf; padding:6px 0;background:#9fa0a4;text-align:center; }");
document.writeln(".box_os .osqq .fshare img{ margin:0 2px; display:inline}.box_os .osqq .fshare span{ display:block; height:20px; text-align:left; text-indent:12px;color:#fff;}");
document.writeln(".box_os .osqq img{ padding:0px 0 3px 0; vertical-align:middle}#finqury{cursor:pointer}");
document.writeln(".acbox .ico_gt{ cursor:pointer; width:169px; height:56px;}");
document.writeln(".onlineService{ background:#9fa0a4; width:57px; height:160px; ;position:fixed; right:0; top:244px; _position:absolute;z-index:99999999;}");
document.writeln(".onlineService .ico_os{ background:url(/images/Common3/skefu_01.png) no-repeat;cursor:pointer; width:57px; height:71px; float:right;}");
document.writeln(".onlineService .ico_gt{ background:url(/images/Common3/skefu_03.png) no-repeat; cursor:pointer; width:57px; height:44px; float:right; clear:both;}");
document.writeln(".onlineService .ico_pp{ background:url(/images/Common3/skefu_02.png) no-repeat; cursor:pointer; width:57px; height:44px; float:right; margin:0 0 1px 0; clear:both;}");
document.writeln(".box_os .osqq p span a{color:#557917;}");
document.writeln("</style>");
document.writeln("<div class=\'box_os\'>");
document.writeln("  <div class=\'os_x\'></div>");
document.writeln("  <div class=\'osqq\'>");
document.writeln("    <div class=\'skype\'>");
document.writeln("      <ul>");

document.writeln("      </ul>");
document.writeln("    </div>");
document.writeln("    <div class=\'app\'>");
document.writeln("      <ul>");
document.writeln("        <li class='email'><a href='mailto:sales@cosmos-dent.com' ><img src='/images/Common3/eico1.png' alt='email' />sales@cosmos-dent.com</a></li>");
document.writeln("        <li><a href='mailto:sales2@cosmos-dent.com'><img src='/images/Common3/eico1.png' alt='email'>sales2@cosmos-dent.com</a></li>");

document.writeln("      </ul>");
document.writeln("    </div>");
document.writeln("    <div class=\'finqury\'><img id=\'finqury\' src=\'/images/Common3/bkefu_02.png\' alt=\'feedback\' /> </div>");
document.writeln("    <div class=\'fshare\'> <span>Follow us :</span> <a href='https://www.facebook.com/cosmosdental520' target='_blank'><img src='/images/Common3/fico1.png' alt='facebook' /></a><a href='https://twitter.com/AmyzhangCosmos' target='_blank'><img src='/images/Common3/tico1.png' alt='Twitter' /></a><a href='#' target='_blank'><img src='/images/Common3/lico1.png' alt='Linkedin' /></a><a href='#' target='_blank'><img src='/images/Common3/pico1.png' alt='Pinterest' /></a><a href='#' target='_blank'><img src='/images/Common3/gico1.png' alt='GooglePlus' /></a></div>");
document.writeln("  </div>");
document.writeln("  <div class=\'acbox\'><a class=\'ico_gt\' href=\'#\' target=\'_self\' title=\'\'><img src=\'/images/Common3/bkefu_03.png\' alt=\'\' /></a> </div>");
document.writeln("</div>");
document.writeln("<div class=\'onlineService\'>");
document.writeln("  <p class=\'ico_os\'></p>");
document.writeln("  <a class=\'ico_pp\'  href=\'javascript:void(0);\' title=\'\'></a> <a class=\'ico_gt\' href=\'#\' target=\'_self\' title=\'\'></a> </div>");

$(function () {
    $('.onlineService .ico_os').click(function () {
        $('#feedback').remove();
        $('.onlineService').hide();
        $('.box_os').show(500);
    });
    $('.os_x').click(function () {
        $('#feedback').remove();
        $('.box_os').hide();
        $('.onlineService').show(200);
    });
    $boxOsFun = function () {
        var st = $(document).scrollTop();
        if (!window.XMLHttpRequest) {
            $('.box_os').css('top', st + 44);
            $('.onlineService').css('top', st + 44);
        }
    };
    $(window).bind('scroll', $boxOsFun);
    $boxOsFun();
    $('.ico_gt').click(function () {
        $("html, body").animate({
            scrollTop: 0
        },
        60);
    })

    $('.ico_pp').click(function () {
        if ($("body #feedback").length > 0) {
        } else {
            FeedbackUtil.feed();
            $('#feedback').css("right", "57px");
        }
    });
    $('#finqury').click(function () {
        if ($("body #feedback").length > 0) {
        } else {
            FeedbackUtil.feed();
            $('#feedback').css("right", "169px");
        }
    });
});