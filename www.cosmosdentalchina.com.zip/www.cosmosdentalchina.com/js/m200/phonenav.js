$(function (){window.onload = function (){
$(".navbar-default").click(function (){
if ($(".nav").css("display") == "none"){
$(".nav").addClass("flexall").slideDown(500);}else{
$(".nav").removeClass("flexall").slideUp(500);}});}
window.onresize = function(){
var w = document.documentElement.scrollWidth || document.body.scrollWidth;
if (w > 767){$(".nav").css("display","block");}else{return;}}});